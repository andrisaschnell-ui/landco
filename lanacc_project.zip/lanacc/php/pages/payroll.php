<?php
// php/pages/payroll.php
require_once __DIR__ . '/../includes/header.php';

$year  = (int)($_GET['year']  ?? date('Y'));
$month = (int)($_GET['month'] ?? date('n'));

// Handle status update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_role('accountant');
    if ($_POST['action'] === 'set_status') {
        DB::run("UPDATE salary_runs SET status=? WHERE id=?",
                [$_POST['status'], (int)$_POST['run_id']]);
        flash("Payroll status updated.");
        redirect('/pages/payroll.php?year='.$year.'&month='.$month);
    }
}

$run = DB::queryOne(
    "SELECT * FROM salary_runs WHERE month=? AND year=?", [$month, $year]
);

$lines = $run ? DB::query(
    "SELECT sl.*, e.name emp_name, e.nib, e.role
     FROM salary_lines sl
     JOIN employees e ON e.id = sl.employee_id
     WHERE sl.salary_run_id=?
     ORDER BY e.name", [$run['id']]
) : [];

$advances = DB::query(
    "SELECT sa.*, e.name emp_name
     FROM salary_advances sa
     JOIN employees e ON e.id=sa.employee_id
     WHERE sa.month_applied=? AND sa.year_applied=?
     ORDER BY e.name", [$month, $year]
);
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0"><i class="bi bi-receipt me-2 text-primary"></i>Payroll</h4>
  <form class="d-flex gap-2">
    <select name="month" class="form-select form-select-sm" style="width:auto">
      <?php for($m=1;$m<=12;$m++): ?>
        <option value="<?=$m?>" <?=$m==$month?'selected':''?>><?=month_name($m)?></option>
      <?php endfor; ?>
    </select>
    <select name="year" class="form-select form-select-sm" style="width:auto">
      <?php for($y=2025;$y<=2027;$y++): ?>
        <option value="<?=$y?>" <?=$y==$year?'selected':''?>><?=$y?></option>
      <?php endfor; ?>
    </select>
    <button class="btn btn-sm btn-outline-primary">Go</button>
  </form>
</div>

<?php if ($run): ?>
<!-- KPI row -->
<div class="row g-2 mb-3">
  <?php $kpis = [
    ['Gross Payroll', $run['total_gross_mzn'],     'people-fill',    'primary'],
    ['Net Payroll',   $run['total_net_mzn'],        'wallet2',        'success'],
    ['INSS Total',    $run['total_inss_employee']+$run['total_inss_employer'], 'shield-check','warning'],
    ['IRPS Total',    $run['total_irps'],            'receipt-cutoff', 'danger'],
  ];
  foreach($kpis as [$lbl,$val,$ico,$col]): ?>
  <div class="col-6 col-xl-3">
    <div class="card border-0 shadow-sm text-center p-3">
      <i class="bi bi-<?=$ico?> text-<?=$col?> fs-4 mb-1"></i>
      <div class="fw-bold"><?=fmt_mzn((float)$val)?></div>
      <div class="text-muted small"><?=$lbl?></div>
    </div>
  </div>
  <?php endforeach; ?>
</div>

<!-- Status -->
<div class="card border-0 shadow-sm mb-3">
  <div class="card-body d-flex justify-content-between align-items-center">
    <div>
      <strong>Payroll Run:</strong> <?=month_name($month)?> <?=$year?> &nbsp;
      <span class="badge bg-<?=$run['status']==='paid'?'success':($run['status']==='submitted'?'warning':'secondary')?>">
        <?=ucfirst($run['status'])?>
      </span>
    </div>
    <?php if($user['role']!=='viewer'): ?>
    <form method="POST" class="d-flex gap-2">
      <input type="hidden" name="action"  value="set_status">
      <input type="hidden" name="run_id"  value="<?=$run['id']?>">
      <select name="status" class="form-select form-select-sm" style="width:auto">
        <option value="draft"     <?=$run['status']==='draft'    ?'selected':''?>>Draft</option>
        <option value="submitted" <?=$run['status']==='submitted'?'selected':''?>>Submitted</option>
        <option value="paid"      <?=$run['status']==='paid'     ?'selected':''?>>Paid</option>
      </select>
      <button type="submit" class="btn btn-sm btn-primary">Update</button>
    </form>
    <?php endif; ?>
  </div>
</div>

<!-- Payroll lines table -->
<div class="card border-0 shadow-sm mb-3">
  <div class="card-header bg-white fw-semibold">Employee Salary Lines</div>
  <div class="table-responsive">
    <table class="table table-hover table-sm mb-0">
      <thead class="table-light">
        <tr>
          <th>Employee</th><th>Role</th><th>NIB</th>
          <th class="text-end">Base</th><th class="text-end">Food</th>
          <th class="text-end">Gross</th><th class="text-end">INSS</th>
          <th class="text-end">IRPS</th><th class="text-end">Net</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($lines as $l): ?>
        <tr>
          <td><strong><?=htmlspecialchars($l['emp_name'])?></strong></td>
          <td><?=htmlspecialchars($l['role']??'—')?></td>
          <td><code><?=$l['nib']??'—'?></code></td>
          <td class="text-end"><?=fmt_mzn((float)$l['base_salary'])?></td>
          <td class="text-end"><?=fmt_mzn((float)$l['food_allowance'])?></td>
          <td class="text-end fw-semibold"><?=fmt_mzn((float)$l['gross_salary'])?></td>
          <td class="text-end text-danger"><?=fmt_mzn((float)$l['inss_employee'])?></td>
          <td class="text-end text-danger"><?=fmt_mzn((float)$l['irps'])?></td>
          <td class="text-end fw-bold text-success"><?=fmt_mzn((float)$l['net_salary'])?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
      <tfoot class="table-secondary fw-bold">
        <tr>
          <td colspan="5">TOTALS</td>
          <td class="text-end"><?=fmt_mzn((float)$run['total_gross_mzn'])?></td>
          <td class="text-end text-danger"><?=fmt_mzn((float)$run['total_inss_employee'])?></td>
          <td class="text-end text-danger"><?=fmt_mzn((float)$run['total_irps'])?></td>
          <td class="text-end text-success"><?=fmt_mzn((float)$run['total_net_mzn'])?></td>
        </tr>
      </tfoot>
    </table>
  </div>
</div>

<?php if(!empty($advances)): ?>
<!-- Advances -->
<div class="card border-0 shadow-sm">
  <div class="card-header bg-white fw-semibold">Salary Advances</div>
  <div class="table-responsive">
    <table class="table table-sm table-hover mb-0">
      <thead class="table-light">
        <tr><th>Employee</th><th>Date</th><th>Description</th><th class="text-end">Amount</th></tr>
      </thead>
      <tbody>
        <?php foreach($advances as $a): ?>
        <tr>
          <td><?=htmlspecialchars($a['emp_name'])?></td>
          <td><?=date('d M Y', strtotime($a['advance_date']))?></td>
          <td><?=htmlspecialchars($a['description']??'—')?></td>
          <td class="text-end"><?=fmt_mzn((float)$a['amount_mzn'])?></td>
        </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<?php else: ?>
<div class="card border-0 shadow-sm">
  <div class="card-body text-center py-5 text-muted">
    <i class="bi bi-receipt fs-1 d-block mb-2"></i>
    No payroll run found for <?=month_name($month)?> <?=$year?>.
    <br>Run the Python ETL script to import salary files.
  </div>
</div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
